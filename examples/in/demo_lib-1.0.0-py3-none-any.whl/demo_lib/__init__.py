"""demo_lib 1.0.0"""

def helper():
    return "helper-v1"

def parse_version(text):
    return text + ".0"

def classify(token):
    return "ok" if token else "empty"

def format_size(n):
    return "%d B" % n
