"""demo_lib 2.0.0"""

def parse_version(text):
    return int(text.split(".")[0])

def classify(token):
    if not token:
        raise ValueError("empty token")
    return "ok"

def format_size(n):
    return "%d byte" % n
